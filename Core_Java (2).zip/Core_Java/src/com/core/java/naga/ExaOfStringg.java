package com.core.java.naga;

public class ExaOfStringg {

	public static void main(String[] args) {
		String str1="PHANI";//ascii a=97
		System.out.println(str1.length());
		System.out.println(str1.toLowerCase());
		System.out.println(str1);
		String str2="Ahani";//A=65
		str1.concat("Hello");
		System.out.println(str1);
		System.out.println(str1==str2);//true
		System.out.println(str1.equals(str2));//true
		System.out.println(str1.compareTo(str2));//0
		//return -value if obj1 comes before obj2
		//return +value if obj1 comes after obj2
		//return 0 when both are same
		
		String str3=new String("Sathwik");
		String str4=new String ("Sathwik");
		
		System.out.println(str3==str4);//false
		System.out.println(str3.equals(str4));//true
		System.out.println(str3.compareTo(str4));//0
		
		StringBuilder sb=new StringBuilder("SathwikNag");
		sb.append("how r u");
		System.out.println(sb);
		
	}

}
