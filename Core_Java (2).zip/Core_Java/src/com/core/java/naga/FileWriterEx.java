package com.core.java.naga;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterEx {

	public static void main(String[] args) throws IOException {
		FileWriter fw=new FileWriter("abc.txt");
		fw.write(65);//fw has a disadvantage as it used to store only characters
		fw.write("Babu\n int elect");
		fw.write("\n");
		
		char[] ch= {'a','b','c'};
		fw.write(ch);
		fw.write("\n");
		fw.close();

	}

}
