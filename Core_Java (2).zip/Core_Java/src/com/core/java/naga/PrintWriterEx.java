package com.core.java.naga;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class PrintWriterEx {
	public static void main(String[] args) throws IOException {
		FileWriter fw=new FileWriter("hoao.txt");
		PrintWriter p=new PrintWriter(fw);
		p.println(1000);
		p.println(false);
		p.println('P');
		p.println("Babu");
		
		p.close();
		fw.close();
		
	}

}
