package com.core.java.naga;

public class MethodOExa {
	public void add(int a,int b) {
		System.out.println("add of two integers:" +(a+b));
	}
	public void add(int a,int b,int c) {
		System.out.println("add of three integers:" +(a+b+c));
	}

	public void add(float a,float b) {
		System.out.println("add of two floats:" +(a+b));
	}

	public void add(int a,float b) {
		System.out.println("add of int and float:" +(a+b));
	}
	public void add(float a,int b) {
		System.out.println("add of float and int:" +(a+b));
	}

	public static void main(String[] args) {
		MethodOExa m=new MethodOExa();
		m.add(10, 20);
		m.add(10, 20, 30);
		m.add(20.3f, 30.7f);
		m.add(20, 20.30f);
		m.add(30.9f, 20);
	}

}
