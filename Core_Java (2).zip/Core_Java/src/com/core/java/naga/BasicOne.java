package com.core.java.naga;

public class BasicOne {
	int d=10;
static int c=30;
	public static void main(String[] args) {
		int a=10;
		BasicOne naga=new BasicOne();
		System.out.println(naga.d);
		System.out.println(BasicOne.c);
		System.out.println(c);
		System.out.println(naga.c);
	}

}
