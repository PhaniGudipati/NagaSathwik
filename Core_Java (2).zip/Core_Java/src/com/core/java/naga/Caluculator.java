package com.core.java.naga;

public class Caluculator {
	int a=100;
	public int addition(int a, int b) {
		System.out.println(a + b);
		return a + b;
	}

	public static void subtraction() {
		int a = 100;
		int b = 50;
		System.out.println(a - b);

	}

	public static int multiplication(int a, int b) {
		System.out.println(a * b);
		return a * b;
	}

	public int division() {
		int a = 10;
		int b = 2;
		System.out.println(a / b);
		return a / b;
	}

	public static void main(String[] args) {
		Caluculator obj = new Caluculator();
		System.out.println(obj);
		System.out.println(obj.toString());
		obj.addition(15, 10);
		Caluculator.subtraction();
		Caluculator.multiplication(10, 5);
		obj.division();
		System.out.println(obj.a);

	}

}
