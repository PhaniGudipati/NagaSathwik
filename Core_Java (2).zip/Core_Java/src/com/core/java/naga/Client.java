package com.core.java.naga;

public class Client {

	public static void main(String[] args) {
	EncapsExa e=new EncapsExa();
	e.setEmpId(100);
	e.setEmpName("Phani");
	e.setEmpSal(1000.0f);
	System.out.println(e.getEmpId());
	System.out.println(e.getEmpName());
	System.out.println(e.getEmpSal());

	}

}
