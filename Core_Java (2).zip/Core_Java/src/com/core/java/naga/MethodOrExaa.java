package com.core.java.naga;
 class Hello{
 int a=20;
	public  void display() {
	
		System.out.println("Helloo" + a);
	}
	
}

public class MethodOrExaa extends Hello {
	int a=205;
	@Override
	public void display() {
		
		System.out.println("hello how are you!!!" +super.a);
		

	}

	public static void main(String[] args) {
		MethodOrExaa m=new MethodOrExaa();
		m.display();

	}

}
