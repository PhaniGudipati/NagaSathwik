package com.core.java.naga;

public class ConExaa {
	ConExaa(){
		
		System.out.println("Default Constr");
	}
ConExaa(String str){
	System.out.println("am Param constructor " + str);
	
}
	public static void main(String[] args) {
		ConExaa c=new ConExaa();
		ConExaa c1=new ConExaa("Sathwik");
		
		
	}

}
