package com.core.java.naga;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class MapEx {

	public static void main(String[] args) {

TreeMap<Integer,String> h=new TreeMap();
h.put(101, "Phani");
h.put(10, "SriLakshmi");
h.put(120, "Naga");
h.put(159, "Sathwik");
h.put(123, "Sai");
h.put(10, "Sree");
h.put(101, "Phani");
System.out.println(h);
Set<Integer> s=h.keySet();
Iterator itr=s.iterator();
while(itr.hasNext()) {
	System.out.println(itr.next());
}
Set<Entry<Integer,String>> s1=h.entrySet();
Iterator itr1=s1.iterator();
while(itr1.hasNext()) {
	System.out.println(itr1.next());
}

	}

}
