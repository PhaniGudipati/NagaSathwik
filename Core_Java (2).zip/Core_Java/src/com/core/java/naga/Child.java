package com.core.java.naga;
interface GrandParent{
	int c=200;
	public void hello();
	public  void add();
}

abstract class Parent implements GrandParent{
	int a = 123;

	public void display() {

		System.out.println("hello am from parent  class");

	}

	

}

public class Child extends Parent {
	int b = 100;

	public void printing() {
		System.out.println("am from child class");

	}

	public static void main(String[] args) {
		Child obj1 = new Child();
		System.out.println(obj1.a);
		obj1.display();
		System.out.println(obj1.b);
		obj1.printing();
	

	}

	@Override
	public void hello() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void add() {
		// TODO Auto-generated method stub
		
	}

}
