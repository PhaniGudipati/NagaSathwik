package com.core.java.naga;

public class Employee implements java.io.Serializable,Cloneable{
	

}
