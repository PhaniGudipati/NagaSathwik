package com.core.java.naga;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class ListExample {

	public static void main(String[] args) {
//		ArrayList al=new ArrayList();//base 10 11 (cc*3/2)+1
//		al.add("Phani");
//		al.add("SriLakshmi");
//		al.add("NagaSathwik");
//		al.add("Ranjith");
//		al.add("Deepak");
//		al.add("Phani");
//		ArrayList al1=new ArrayList();//base 10 11 (cc*3/2)+1
//		al1.add("Nag");
//		al1.add("Chiranjeev");
//		al1.add("Megastar");
//		al1.add("Rajini");
//		al1.add("Babu");
//		al1.add("kumar");
//	
//		//System.out.println(al.addAll(al1));
//		System.out.println(al.removeAll(al1));
//		System.out.println(al);
//		Iterator itr=al.iterator();
//		while(itr.hasNext()) {
//			System.out.println(itr.next());
		
		
		//}
		ReverseOrder r=new ReverseOrder();
		TreeSet<String> t=new TreeSet(r);
		t.add("Ayush");
		t.add("Harry");
		t.add("Sathwik");
		t.add("Sri");
		t.add("Phani");
		t.add("Zoo");
		System.out.println(t);
		Iterator itr=t.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		
		
		}
		
	}}
	
	class ReverseOrder implements Comparator<String>{

		@Override
		public int compare(String a, String b) {
			// TODO Auto-generated method stub
			return b.compareTo(a);
		}
		
		
	

	}


