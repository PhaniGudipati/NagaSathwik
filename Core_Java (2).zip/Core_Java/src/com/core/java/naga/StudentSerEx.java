package com.core.java.naga;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class StudentSerEx {
	public static void main(String[] args) throws IOException {
		Student std=new Student(123,"Babu",90000);
		
		FileOutputStream out=new FileOutputStream("kaka.txt");
		ObjectOutputStream obj=new ObjectOutputStream(out);
		obj.writeObject(std);
		System.out.println("Serialization is com");
	}

}

