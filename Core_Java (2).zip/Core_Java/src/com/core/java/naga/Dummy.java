package com.core.java.naga;

import java.util.Scanner;

public class Dummy {

	public static void main(String[] args) {
		int a[][]={ {10,20,30,40},{50,60,70,80}};
		System.out.println(a[1][0]);
	
	}

}
