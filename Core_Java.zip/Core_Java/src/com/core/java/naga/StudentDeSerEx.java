package com.core.java.naga;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class StudentDeSerEx {
public static void main(String[] args) throws IOException, ClassNotFoundException {
	FileInputStream out=new FileInputStream("kaka.txt");
	ObjectInputStream obj=new ObjectInputStream(out);
	Student std=(Student)obj.readObject();
	System.out.println(std);
	System.out.println("Deseri is com");
}
}
