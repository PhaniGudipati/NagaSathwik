package com.core.java.naga;

import java.io.File;
import java.io.IOException;

public class FileEx {
	public static void main(String[] args) throws IOException {
		File f = new File("sathu.txt");
		System.out.println(f.exists());// check wheather the file is existing or not if not return false
		System.out.println(f.createNewFile());//it will create the file
		//System.out.println(f.mkdir());

		//System.out.println(f.setReadOnly());
		System.out.println(f.exists());
		System.out.println(f.isDirectory());
		System.out.println(f.isFile());
	}
}
