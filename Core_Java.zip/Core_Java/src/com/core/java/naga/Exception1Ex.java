package com.core.java.naga;

import java.util.Scanner;

public class Exception1Ex {

	public static void main(String[] args) {

Scanner scan=new Scanner(System.in); //try ==error code ,catch==handling code
System.out.println("enter the Numorator for division");
int a=scan.nextInt();
System.out.println("enter the Denominator for division");
int b=scan.nextInt();
try {
int c=a/b;
System.out.println(c);
}catch(Exception e) {
	System.out.println("Dont Enter ZERO as Denominator");
}
System.out.println("Remaining 1000 lines.......");


	}

}
