package com.core.java.naga;

public class WrapsEx {

	public static void main(String[] args) {
		
		
		String str="100";//autoboxing,unboxing 
		String str1="200";
		//System.out.println(str+str1);
		int x=Integer.parseInt(str);
		int y=Integer.parseInt(str1);
		System.out.println(x+y);
		Integer z=Integer.parseInt(str);
		
		System.out.println(z+ "200");
		

	}

}
