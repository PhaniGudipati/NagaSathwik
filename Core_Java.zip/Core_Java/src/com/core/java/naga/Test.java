package com.core.java.naga;

import java.lang.reflect.*;

class Test {
	public static void main(String[] args)throws Exception {
		Class c=Class.forName("Employee");
		
		System.out.println("Name :" +c.getName());
		System.out.println("Super class:"+c.getSuperclass().getName());
		Class[] cl=c.getInterfaces();
		System.out.println("Interface list:");
		for(Class cls:cl) {
			System.out.println(cls.getName());
		}
		System.out.println();
		int i=c.getModifiers();
		System.out.println("Access Modifiers:" + Modifier.toString(i));
	}

}
