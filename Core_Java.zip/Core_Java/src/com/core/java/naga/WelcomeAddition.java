package com.core.java.naga;

import java.util.Scanner;

public class WelcomeAddition {

	public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter the 1st number:");
	int a=scan.nextInt();
	System.out.println("Enter the 2nd number:");
	int b=scan.nextInt();
	System.out.println("add of two :" + (a*b));
	

	}

}
